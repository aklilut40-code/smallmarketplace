import { useState } from "react";
import useAuth from "../hooks/useAuth";

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState({ name: user?.name || "", phone: user?.phone || "", password: "" });
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");
    setSubmitting(true);
    try {
      const payload = { name: form.name, phone: form.phone };
      if (form.password) payload.password = form.password;
      await updateProfile(payload);
      setMessage("Profile updated");
      setForm({ ...form, password: "" });
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="section auth-page">
      <h1>My profile</h1>
      <form className="form" onSubmit={handleSubmit}>
        {error && <div className="form-error">{error}</div>}
        {message && <div className="form-success">{message}</div>}
        <label>Name</label>
        <input name="name" value={form.name} onChange={handleChange} required />
        <label>Email</label>
        <input value={user?.email || ""} disabled />
        <label>Phone</label>
        <input name="phone" value={form.phone} onChange={handleChange} />
        <label>New password (leave blank to keep current)</label>
        <input name="password" type="password" value={form.password} onChange={handleChange} minLength={6} />
        <button type="submit" className="btn-solid" disabled={submitting}>
          {submitting ? "Saving..." : "Save changes"}
        </button>
      </form>
    </div>
  );
}
