import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getProductById } from "../services/productService";
import { addFavorite, removeFavorite, getFavorites } from "../services/favoriteService";
import { formatPrice } from "../utils/format";
import useAuth from "../hooks/useAuth";
import Loader from "../components/Loader";

export default function ProductDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  const API_ROOT = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace("/api", "");

  useEffect(() => {
    getProductById(id)
      .then(setProduct)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (user) {
      getFavorites(user.token)
        .then((favs) => setSaved(favs.some((f) => f._id === id)))
        .catch(() => {});
    }
  }, [user, id]);

  const toggleSave = async () => {
    if (!user) return;
    if (saved) {
      await removeFavorite(id, user.token);
      setSaved(false);
    } else {
      await addFavorite(id, user.token);
      setSaved(true);
    }
  };

  if (loading) return <Loader />;
  if (error) return <p className="empty-state">{error}</p>;
  if (!product) return null;

  return (
    <div className="section product-details">
      <Link to="/products" className="back-link">← Back to products</Link>
      <div className="product-details-grid">
        <div className="product-details-image">
          {product.image ? (
            <img src={`${API_ROOT}${product.image}`} alt={product.name} />
          ) : (
            <div className="image-placeholder">No image</div>
          )}
        </div>
        <div className="product-details-info">
          <span className="product-card-category">{product.category}</span>
          <h1>{product.name}</h1>
          <div className="product-card-price large">{formatPrice(product.price)}</div>
          <p className="product-details-location">📍 {product.location}</p>
          <p>{product.description}</p>

          <div className="product-details-seller">
            <strong>Seller:</strong> {product.seller?.name}
            <br />
            <strong>Contact:</strong> {product.contact}
          </div>

          {user && (
            <button className="btn-ghost" onClick={toggleSave}>
              {saved ? "♥ Saved" : "♡ Save product"}
            </button>
          )}
          {!user && <p className="empty-state">Log in to save this product or contact the seller directly.</p>}
        </div>
      </div>
    </div>
  );
}
