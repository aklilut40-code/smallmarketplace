import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getProducts } from "../services/productService";
import ProductCard from "../components/ProductCard";
import Loader from "../components/Loader";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProducts()
      .then((data) => setProducts(data.slice(0, 6)))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <section className="hero">
        <h1>Buy and sell, right in your community.</h1>
        <p>Browse listings from real sellers, or list something of your own in minutes.</p>
        <div className="hero-actions">
          <Link to="/products" className="btn-solid">Browse products</Link>
          <Link to="/dashboard" className="btn-ghost">Start selling</Link>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Recently listed</h2>
          <Link to="/products">See all →</Link>
        </div>
        {loading ? (
          <Loader />
        ) : products.length === 0 ? (
          <p className="empty-state">No products yet — be the first to list one.</p>
        ) : (
          <div className="product-grid">
            {products.map((p) => (
              <ProductCard key={p._id} product={p} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
