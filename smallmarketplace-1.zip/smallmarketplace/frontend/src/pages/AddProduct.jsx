import { useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";
import { createProduct } from "../services/productService";
import ProductForm from "../components/ProductForm";

export default function AddProduct() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (formData) => {
    await createProduct(formData, user.token);
    navigate("/dashboard");
  };

  return (
    <div className="section auth-page">
      <h1>Add a product</h1>
      <ProductForm onSubmit={handleSubmit} submitLabel="List product" />
    </div>
  );
}
