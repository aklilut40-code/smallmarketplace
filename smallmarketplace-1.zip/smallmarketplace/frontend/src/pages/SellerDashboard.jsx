import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import useAuth from "../hooks/useAuth";
import { getMyProducts, deleteProduct } from "../services/productService";
import { formatPrice } from "../utils/format";
import Loader from "../components/Loader";

export default function SellerDashboard() {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getMyProducts(user.token)
      .then(setProducts)
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  const handleDelete = async (id) => {
    if (!confirm("Delete this listing?")) return;
    await deleteProduct(id, user.token);
    load();
  };

  return (
    <div className="section">
      <div className="section-head">
        <h1>My listings</h1>
        <Link to="/dashboard/add" className="btn-solid">+ Add product</Link>
      </div>

      {loading ? (
        <Loader />
      ) : products.length === 0 ? (
        <p className="empty-state">You haven't listed anything yet.</p>
      ) : (
        <div className="dashboard-list">
          {products.map((p) => (
            <div key={p._id} className="dashboard-row">
              <div>
                <strong>{p.name}</strong>
                <span className="dashboard-meta">{p.category} · {formatPrice(p.price)}</span>
              </div>
              <div className="dashboard-actions">
                <Link to={`/dashboard/edit/${p._id}`} className="btn-ghost">Edit</Link>
                <button className="btn-danger" onClick={() => handleDelete(p._id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
