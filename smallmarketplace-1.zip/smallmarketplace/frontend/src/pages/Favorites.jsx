import { useEffect, useState } from "react";
import useAuth from "../hooks/useAuth";
import { getFavorites } from "../services/favoriteService";
import ProductCard from "../components/ProductCard";
import Loader from "../components/Loader";

export default function Favorites() {
  const { user } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getFavorites(user.token)
      .then(setProducts)
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
  }, [user]);

  return (
    <div className="section">
      <h1>Saved products</h1>
      {loading ? (
        <Loader />
      ) : products.length === 0 ? (
        <p className="empty-state">You haven't saved anything yet.</p>
      ) : (
        <div className="product-grid">
          {products.map((p) => (
            <ProductCard key={p._id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
