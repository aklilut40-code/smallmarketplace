import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";
import { getProductById, updateProduct } from "../services/productService";
import ProductForm from "../components/ProductForm";
import Loader from "../components/Loader";

export default function EditProduct() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProductById(id)
      .then(setProduct)
      .finally(() => setLoading(false));
  }, [id]);

  const handleSubmit = async (formData) => {
    await updateProduct(id, formData, user.token);
    navigate("/dashboard");
  };

  if (loading) return <Loader />;
  if (!product) return <p className="empty-state">Product not found.</p>;

  return (
    <div className="section auth-page">
      <h1>Edit product</h1>
      <ProductForm initial={product} onSubmit={handleSubmit} submitLabel="Save changes" />
    </div>
  );
}
