import Navbar from "../components/Navbar";

export default function MainLayout({ children }) {
  return (
    <div className="app-shell">
      <Navbar />
      <main className="app-content">{children}</main>
      <footer className="app-footer">smallmarketplace — buy and sell locally</footer>
    </div>
  );
}
