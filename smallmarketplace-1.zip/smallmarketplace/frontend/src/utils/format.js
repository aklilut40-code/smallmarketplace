export function formatPrice(value) {
  const num = Number(value);
  if (Number.isNaN(num)) return value;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(num);
}

export const CATEGORIES = [
  "All",
  "Electronics",
  "Clothing",
  "Home & Garden",
  "Vehicles",
  "Books",
  "Sports",
  "Toys",
  "Other",
];
