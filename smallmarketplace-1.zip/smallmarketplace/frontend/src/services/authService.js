import request from "./api";

export const registerUser = (data) => request("/auth/register", { method: "POST", body: data });

export const loginUser = (data) => request("/auth/login", { method: "POST", body: data });

export const getProfile = (token) => request("/auth/profile", { token });

export const updateProfile = (data, token) =>
  request("/auth/profile", { method: "PUT", body: data, token });
