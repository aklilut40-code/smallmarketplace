import request from "./api";

export const getProducts = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return request(`/products${query ? `?${query}` : ""}`);
};

export const getProductById = (id) => request(`/products/${id}`);

export const getMyProducts = (token) => request("/products/mine/list", { token });

export const createProduct = (formData, token) =>
  request("/products", { method: "POST", body: formData, token, isForm: true });

export const updateProduct = (id, formData, token) =>
  request(`/products/${id}`, { method: "PUT", body: formData, token, isForm: true });

export const deleteProduct = (id, token) =>
  request(`/products/${id}`, { method: "DELETE", token });
