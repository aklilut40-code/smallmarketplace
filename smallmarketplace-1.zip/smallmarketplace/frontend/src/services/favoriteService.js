import request from "./api";

export const getFavorites = (token) => request("/favorites", { token });

export const addFavorite = (productId, token) =>
  request(`/favorites/${productId}`, { method: "POST", token });

export const removeFavorite = (productId, token) =>
  request(`/favorites/${productId}`, { method: "DELETE", token });
