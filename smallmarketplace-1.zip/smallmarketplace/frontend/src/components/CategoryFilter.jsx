import { CATEGORIES } from "../utils/format";

export default function CategoryFilter({ value, onChange }) {
  return (
    <div className="category-filter">
      {CATEGORIES.map((c) => (
        <button
          key={c}
          className={"chip" + (value === c ? " active" : "")}
          onClick={() => onChange(c)}
        >
          {c}
        </button>
      ))}
    </div>
  );
}
