import { useState } from "react";
import { CATEGORIES } from "../utils/format";

export default function ProductForm({ initial = {}, onSubmit, submitLabel = "Save" }) {
  const [form, setForm] = useState({
    name: initial.name || "",
    description: initial.description || "",
    price: initial.price || "",
    category: initial.category || CATEGORIES[1],
    location: initial.location || "",
    contact: initial.contact || "",
  });
  const [imageFile, setImageFile] = useState(null);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const data = new FormData();
      Object.entries(form).forEach(([k, v]) => data.append(k, v));
      if (imageFile) data.append("image", imageFile);
      await onSubmit(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      {error && <div className="form-error">{error}</div>}

      <label>Product name</label>
      <input name="name" value={form.name} onChange={handleChange} required />

      <label>Description</label>
      <textarea name="description" value={form.description} onChange={handleChange} rows={4} required />

      <div className="form-row">
        <div>
          <label>Price (USD)</label>
          <input name="price" type="number" min="0" value={form.price} onChange={handleChange} required />
        </div>
        <div>
          <label>Category</label>
          <select name="category" value={form.category} onChange={handleChange}>
            {CATEGORIES.filter((c) => c !== "All").map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
      </div>

      <label>Location</label>
      <input name="location" value={form.location} onChange={handleChange} required />

      <label>Contact information</label>
      <input name="contact" value={form.contact} onChange={handleChange} placeholder="Phone or email" required />

      <label>Product image</label>
      <input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} />

      <button type="submit" className="btn-solid" disabled={submitting}>
        {submitting ? "Saving..." : submitLabel}
      </button>
    </form>
  );
}
