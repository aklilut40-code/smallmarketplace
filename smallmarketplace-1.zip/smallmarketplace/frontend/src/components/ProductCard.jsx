import { Link } from "react-router-dom";
import { formatPrice } from "../utils/format";

export default function ProductCard({ product }) {
  const API_ROOT = (import.meta.env.VITE_API_URL || "http://localhost:5000/api").replace("/api", "");
  const imageSrc = product.image ? `${API_ROOT}${product.image}` : null;

  return (
    <Link to={`/products/${product._id}`} className="product-card">
      <div className="product-card-image">
        {imageSrc ? <img src={imageSrc} alt={product.name} /> : <div className="image-placeholder">No image</div>}
      </div>
      <div className="product-card-body">
        <span className="product-card-category">{product.category}</span>
        <h3>{product.name}</h3>
        <p className="product-card-location">{product.location}</p>
        <div className="product-card-price">{formatPrice(product.price)}</div>
      </div>
    </Link>
  );
}
