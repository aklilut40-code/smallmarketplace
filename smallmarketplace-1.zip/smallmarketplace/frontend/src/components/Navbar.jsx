import { Link, useNavigate } from "react-router-dom";
import useAuth from "../hooks/useAuth";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          small<em>market</em>
        </Link>
        <nav className="nav-links">
          <Link to="/products">Browse</Link>
          {user && <Link to="/favorites">Saved</Link>}
          {user && <Link to="/dashboard">Dashboard</Link>}
        </nav>
        <div className="nav-actions">
          {user ? (
            <>
              <Link to="/profile" className="nav-user">{user.name}</Link>
              <button className="btn-ghost" onClick={handleLogout}>Log out</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost">Log in</Link>
              <Link to="/register" className="btn-solid">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
