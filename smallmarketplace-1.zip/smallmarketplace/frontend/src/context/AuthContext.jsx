import { createContext, useState, useEffect } from "react";
import { loginUser, registerUser, updateProfile as updateProfileApi } from "../services/authService";

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("smallmarketplace_user");
    if (stored) setUser(JSON.parse(stored));
    setLoading(false);
  }, []);

  const persist = (data) => {
    setUser(data);
    localStorage.setItem("smallmarketplace_user", JSON.stringify(data));
  };

  const login = async (email, password) => {
    const data = await loginUser({ email, password });
    persist(data);
    return data;
  };

  const register = async (name, email, password, phone) => {
    const data = await registerUser({ name, email, password, phone });
    persist(data);
    return data;
  };

  const updateProfile = async (fields) => {
    const data = await updateProfileApi(fields, user.token);
    persist(data);
    return data;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("smallmarketplace_user");
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}
