import Product from "../models/Product.js";

// @desc   Get all products (supports search + category filter)
// @route  GET /api/products?search=&category=
export const getProducts = async (req, res, next) => {
  try {
    const { search, category } = req.query;
    const query = {};

    if (search) {
      query.$text = { $search: search };
    }
    if (category && category !== "All") {
      query.category = category;
    }

    const products = await Product.find(query)
      .populate("seller", "name email phone")
      .sort({ createdAt: -1 });

    res.json(products);
  } catch (error) {
    next(error);
  }
};

// @desc   Get single product
// @route  GET /api/products/:id
export const getProductById = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate("seller", "name email phone");
    if (!product) return res.status(404).json({ message: "Product not found" });
    res.json(product);
  } catch (error) {
    next(error);
  }
};

// @desc   Create a product
// @route  POST /api/products
export const createProduct = async (req, res, next) => {
  try {
    const { name, description, price, category, location, contact } = req.body;

    if (!name || !description || !price || !category || !location || !contact) {
      return res.status(400).json({ message: "Please fill in all required fields" });
    }

    const product = await Product.create({
      name,
      description,
      price,
      category,
      location,
      contact,
      image: req.file ? `/uploads/${req.file.filename}` : "",
      seller: req.user._id,
    });

    res.status(201).json(product);
  } catch (error) {
    next(error);
  }
};

// @desc   Update a product (only the seller who owns it)
// @route  PUT /api/products/:id
export const updateProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found" });

    if (product.seller.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to edit this product" });
    }

    const fields = ["name", "description", "price", "category", "location", "contact"];
    fields.forEach((f) => {
      if (req.body[f] !== undefined) product[f] = req.body[f];
    });
    if (req.file) product.image = `/uploads/${req.file.filename}`;

    const updated = await product.save();
    res.json(updated);
  } catch (error) {
    next(error);
  }
};

// @desc   Delete a product (only the seller who owns it)
// @route  DELETE /api/products/:id
export const deleteProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found" });

    if (product.seller.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to delete this product" });
    }

    await product.deleteOne();
    res.json({ message: "Product removed" });
  } catch (error) {
    next(error);
  }
};

// @desc   Get products listed by the logged-in seller
// @route  GET /api/products/mine/list
export const getMyProducts = async (req, res, next) => {
  try {
    const products = await Product.find({ seller: req.user._id }).sort({ createdAt: -1 });
    res.json(products);
  } catch (error) {
    next(error);
  }
};
