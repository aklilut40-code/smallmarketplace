import Favorite from "../models/Favorite.js";

// @desc   Get logged-in user's favorite products
// @route  GET /api/favorites
export const getFavorites = async (req, res, next) => {
  try {
    const favorites = await Favorite.find({ user: req.user._id }).populate({
      path: "product",
      populate: { path: "seller", select: "name email phone" },
    });
    res.json(favorites.map((f) => f.product).filter(Boolean));
  } catch (error) {
    next(error);
  }
};

// @desc   Add a product to favorites
// @route  POST /api/favorites/:productId
export const addFavorite = async (req, res, next) => {
  try {
    const existing = await Favorite.findOne({ user: req.user._id, product: req.params.productId });
    if (existing) return res.status(400).json({ message: "Already saved" });

    await Favorite.create({ user: req.user._id, product: req.params.productId });
    res.status(201).json({ message: "Added to favorites" });
  } catch (error) {
    next(error);
  }
};

// @desc   Remove a product from favorites
// @route  DELETE /api/favorites/:productId
export const removeFavorite = async (req, res, next) => {
  try {
    await Favorite.findOneAndDelete({ user: req.user._id, product: req.params.productId });
    res.json({ message: "Removed from favorites" });
  } catch (error) {
    next(error);
  }
};
