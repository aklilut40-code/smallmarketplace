# smallmarketplace

A small, beginner-friendly marketplace web app where users can browse products and sellers can list items for sale.

## What this project does

- Anyone can browse, search, and filter product listings
- Users can register, log in, and manage their profile
- Logged-in users can list products for sale, edit or delete their own listings, and upload a product image
- Users can save/favorite products they're interested in
- Buyers can see seller contact info directly on each product page

## Technologies used

**Frontend:** React, Vite, React Router, plain CSS
**Backend:** Node.js, Express, MongoDB, Mongoose, JWT auth, bcrypt password hashing, Multer (image uploads)

## Project structure

```
smallmarketplace/
├── backend/
│   ├── src/
│   │   ├── config/       # database connection
│   │   ├── models/       # Mongoose schemas (User, Product, Favorite)
│   │   ├── controllers/  # route logic
│   │   ├── routes/       # Express routers
│   │   └── middleware/   # auth, upload, error handling
│   ├── server.js
│   ├── .env.example
│   └── package.json
└── frontend/
    ├── src/
    │   ├── components/   # reusable UI pieces
    │   ├── pages/        # route-level views
    │   ├── layouts/       # page shell
    │   ├── services/      # API calls
    │   ├── context/       # auth state
    │   ├── hooks/
    │   ├── utils/
    │   ├── App.jsx
    │   └── main.jsx
    ├── .env.example
    └── package.json
```

## Required environment variables

### backend/.env
```
PORT=5000
MONGO_URI=your MongoDB Atlas connection string
JWT_SECRET=a long random string
CLIENT_URL=the URL your frontend runs on
```

### frontend/.env
```
VITE_API_URL=the URL your backend API runs on, ending in /api
```

Never commit real `.env` files — only the `.env.example` templates are tracked in this repo.

## How to install and run

### Backend
```
cd backend
npm install
cp .env.example .env    # then fill in your real values
npm run dev
```

### Frontend
```
cd frontend
npm install
cp .env.example .env    # then fill in your real values
npm run dev
```

The frontend runs at `http://localhost:5173` and expects the backend API at the URL set in `VITE_API_URL`.

## How to deploy

1. **Database:** Create a free cluster on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas), and use its connection string as `MONGO_URI`.
2. **Backend:** Deploy the `backend/` folder to a Node host such as [Render](https://render.com) or [Railway](https://railway.app). Set the environment variables (`MONGO_URI`, `JWT_SECRET`, `CLIENT_URL`, `PORT`) in that host's dashboard — never in the code.
3. **Frontend:** Deploy the `frontend/` folder to [Vercel](https://vercel.com), [Netlify](https://netlify.com), or GitHub Pages. Set `VITE_API_URL` to your deployed backend's URL (e.g. `https://your-backend.onrender.com/api`).
4. Update the backend's `CLIENT_URL` to match your deployed frontend's URL, so CORS allows requests from it.
